package com.niit.OnlineCollaboration;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class OnlineCollaborationApplicationTests {

	@Test
	void contextLoads() {
	}

}
